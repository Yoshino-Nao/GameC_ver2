#pragma once
#include<GLLibrary.h>
#define GRAVITY (9.8f/20)
enum {
	eType_Field,
	eType_Player,
	eType_Enemy,
	eType_Player_Attack,
	eType_Enemy_Attack,
	eType_Effect,
	eType_Scene,
	eType_Goal,
	//eType_Bullet,
	//eType_Effect,
	eType_UI,
};

class Base {
public:
	int m_type;
	float m_rad;
	CVector2D m_pos;
	//�ړ��x�N�g��
	CVector2D m_vec;
	bool m_kill;
	static std::list<Base*>m_list;
	Base* Base::FindObject(int type);
	//�Z�`
	CRect m_rect;
	
public:
	Base(int type);
	virtual ~Base();
	virtual void Update();
	virtual void Draw();
	virtual void Collision(Base* b);
	void SetKill() { m_kill = true; }
	
	
	static bool CollisionCircle(Base* b1, Base* b2);
	static void UpdateAll();
	static void DrawAll();
	static void CollisionAll();
	static void Add(Base* b);
	static void KillAll();
	static void CheckKillAll();
	static std::list<Base*>FindObjects(int type);
	static CVector2D m_scroll;
	static CVector2D GetScreenPos(const CVector2D& pos);
	//�Z�`���m�̔���
	static bool CollsionRect(Base* b1, Base* b2);
	//�Z�`�̕\��
	void DrawRect();
};
